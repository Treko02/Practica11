#ifndef LIBRO_LIBRARY_H
#define LIBRO_LIBRARY_H
struct tlibro;
void MostrarLibro(tlibro l);
void LeerLibro(tlibro l);
void copiaLibro(tlibro l);
void cambiarAnio(tlibro l);

#endif //LIBRO_LIBRARY_H
