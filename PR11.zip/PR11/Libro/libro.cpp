#include "libro.h"
#include "string.h"
#include <iostream>
using namespace std;

struct tlibro{
    char ISBM[10];
    char titulo[15];
    int anio;
};

void MostrarLibro(tlibro l) {
    int n=0;
    while (n!=4){
        cout<<"Elige el dato a visualizar"<<endl;
        cout<<"1. ISBM"<<endl;
        cout<<"2. Titulo"<<endl;
        cout<<"3. anio"<<endl;
        cin>>n;
        switch (n) {
            case 1: cout<<l.ISBM<<endl;
                break;
            case 2: cout<<l.titulo<<endl;
                break;
            case 3: cout<<l.anio<<endl;
                break;
            case 4: cout<<"Salir"<<endl;
        }
    }
}
void LeerLibro(tlibro l){
    cout<<"Introduce su ISBM"<<endl;
    cin.getline(l.ISBM, 10, '\n');
    cout<<endl;
    cout<<"Introduce su titulo"<<endl;
    cin.getline(l.titulo, 15, '\n');
    cout<<endl;
    cout<<"Introduce su anio de publicacion"<<endl;
    cin>>l.anio;
}
void copiaLibro(tlibro l){
    tlibro lcopy;
    strcpy(lcopy.ISBM, l.ISBM);
    strcpy(lcopy.titulo, l.titulo);
    lcopy.anio=l.anio;
    cout<<"Los datos introducidos son: "<<l.ISBM<<"  "<<l.titulo<<"  "<<l.anio;
}
void cambiarAnio(tlibro l) {
    int newAnio;
    cout<<"Introduce el nuevo anio: "<<endl;
    cin>>newAnio;
    cout<<endl;
    if (newAnio==l.anio){
        cout<<"El anio es el mismo"<<endl;
    }else{
        l.anio=newAnio;
        cout<<"Cambio realizado"<<endl;
    }
}

