#include "bibliografia.h"
#include "libro.h"
#include <iostream>

struct tbibliografia{
    tlibro
};

void hello() {

}
